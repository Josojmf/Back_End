import { Request, Response, NextFunction } from 'express';
import axios, { AxiosResponse } from 'axios';
import { strictEqual } from 'assert';
//import {MongoClient} from "mongodb";
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://joso:123456abc@cluster0.6xzff.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
let aux1:any;

let dateSplit: string[];
interface Post {
    userId: Number;
    id: Number;
    title: String;
    body: String;
}
type data = {
    day: number,
    month: number,
    year: number,
    seat: number,
}


const getStatus = async (req: Request, res: Response, next: NextFunction) => {
    let currentDate = new Date().toLocaleDateString();
    let splitDate: string[];
    splitDate = currentDate.split("/", 20);
    //dateSplit=splitDate;
    if (res.statusCode === 200) {
        return res.json({
            Status: res.statusCode,
            Body: `${splitDate[0]} - ${splitDate[1]} - ${splitDate[2]} `
        })
    } else {
        return res.json({
            Status: res.statusCode,
            Body: "Not Found"
        })
    }
}
const getSeats = async (req: Request, res: Response, next: NextFunction) => {
    // get the post id from the req
    let date:string= req.params.id;
    let retSeat;
    let splitDate: string[] = date.split(":", 20);
    MongoClient.connect(`mongodb+srv://joso:123456abc@cluster0.6xzff.mongodb.net/myFirstDatabase?retryWrites=true&w=majority$`, function(err:any, db1:any) {
    var dbo = db1.db("MyDbBackend");
    dbo.collection("Seats").find({day:parseInt(splitDate[0]),month:parseInt(splitDate[1]),year:parseInt(splitDate[2])}).toArray(function(err:any, result:data) {
      db1.close();
      aux1=result;

    });
  }); 

   if(aux1){
      
    Object.keys(aux1 as data).forEach((k: string) =>{
       console.log(k);
        if (k =="seat"){
            console.log("inside")
            retSeat=`${(aux1)[k]}`
  
        }
    })

   }

    
    return res.status(200).json({
        Body:retSeat

      
    });
};


export default { getSeats, getStatus }